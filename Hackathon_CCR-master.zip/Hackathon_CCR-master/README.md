# Repositório do time #36 do Hackathon_CCR
Neste repositório estão contidos os arquivos referentes à parte programática da solução apresentada.
A solução é um sistema dual chamado Bino, composto pelo Bino Bot (chatbot de whatsapp) e o Bino App (applicativo que expande as funcionalides obtidas com o uso do chatbot).

Em sua forma chatbot, o bino se restringe ao envio de mensagens de texto com alertas, e recebimento de alertas por parte dos usuarios, que interagirão com ele via mensagens de texto pelo aplicativo Whatsapp.

A versão aplicativo traz funcionalidades avançadas, podendo ser controlada por comandos de voz, e comunicando-se com os usuários através de alertas sonoros e voz sintética, conferindo maior segurança e comodidade. Tal funcionalidade também servirá de canal aberto para aproximar caminhoneiros de anunciantes, trazendo assim benefício mútuo.
