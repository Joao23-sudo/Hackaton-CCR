Aqui constam os arquivos referentes ao Bino Bot. O Bot foi desenvolvido utilizando o Google Dialog Flow, e pode ser testado adicionando
o número **+55 73 98894 - 3644** no Whatsapp, e mandando um oi. O Bot então iniciará a interação com o usuário e fornecerá opções que permitem
o usuário opte por receber notificações e configurar quais notificações deseja receber.

O protótipo inicial conta com os aplicativos Whatsapp Business e WhatsBot para seu funcionamento. Ambos disponíveis gratuitamentes na
Play Store.

Para instalação do protótipo, os seguintes passos devem ser seguidos:
1 - Fazer download do arquivo BinoBot.json e transferí-lo para o armazenamento do smartphone, Bluestacks (onde o bot será hospedado)
2 - Baixar, instalar e iniciar uma conta do Whatsapp Business
3 - Baixar, instalar e autorizar o applicativo WhatsBot
4 - Abrir o Whatsbot, clicar em configurar nova regra, em tipo de regra selecionar: I.A. ARBot DialogFlow
5 - Selecionar o arquivo BinoBot.json
6 - Confirmar a seleção.

Pronto, o Bino Bot está configurado e pronto para ser usado.
