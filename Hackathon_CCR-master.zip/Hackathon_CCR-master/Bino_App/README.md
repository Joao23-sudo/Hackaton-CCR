Nesta pasta encontram-se as telas do protótipo do aplicativo, produzidas utillizando o Figma. O protótipo do aplicativo pode
ser acessado através do link abaixo.

https://www.figma.com/proto/4gLvPiSVFZhDtXrkDZ7imB/Bino?node-id=1%3A2&scaling=scale-down 

Em sua versão definitiva, o aplicativo contará com integração com o Waze via API (https://www.waze.com/sdk) enquanto a voz será gerada
através da integração com os serviços Google Cloud, o que também permitirá que o usuário comande o aplicativo através de voz.

Por fim, o envio de alertas via SMS será realizado através da integração com o Twilio.
